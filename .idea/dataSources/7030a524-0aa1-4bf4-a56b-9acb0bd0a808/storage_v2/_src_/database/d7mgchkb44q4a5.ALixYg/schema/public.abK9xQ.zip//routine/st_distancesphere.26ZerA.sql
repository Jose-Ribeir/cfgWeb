create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
select public.ST_distance( public.geography($1), public.geography($2),false)
$$;

comment on function st_distancesphere(geometry, geometry) is 'args: geomlonlatA, geomlonlatB - Returns minimum distance in meters between two lon/lat geometries using a spherical earth model.';

alter function st_distancesphere(geometry, geometry) owner to postgres;

