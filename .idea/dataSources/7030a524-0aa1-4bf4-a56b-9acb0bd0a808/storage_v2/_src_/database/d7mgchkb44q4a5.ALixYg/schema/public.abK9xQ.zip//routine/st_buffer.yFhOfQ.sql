create function st_buffer(text, double precision, text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Buffer($1::public.geometry, $2, $3);
$$;

alter function st_buffer(text, double precision, text) owner to postgres;

